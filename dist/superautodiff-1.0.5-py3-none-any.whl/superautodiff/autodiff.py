from collections import Counter
import math

class AutoDiff():
    """Creates an object for autodifferentiation

    ATTRIBUTES
    ==========
    var : name of variables
    val : the value of the object
    der : the derivative of the object

    EXAMPLES
    ========
    >>> x = AutoDiff("x",4)
    >>> x.var
    'x'
    >>> x.val
    4.0
    >>> x.der
    Counter({'x': 1.0})
    """

    def __init__(self, var, val, der=1.0):

        #add exception for using same variable name?
        if type(var) == int or type(var) == float:
            raise ValueError("Input variable name should be a string")
        elif type(var) == str:
            self.var = var

        if type(val)==list or type(val)==str:
            raise ValueError("Input value should be integer or float")
        else:
            self.val = float(val)
        
        if type(der) != float:
            self.der = der
        else:
            self.der = Counter({var: der})

    def __add__(self, other):
        """Performs addition on two AutoDiff objects"""

        if type(other).__name__ is 'AutoDiffVector':
            return other.__add__(self)
        
        try:
            total = Counter()
            total.update(self.der)
            total.update(other.der)
        
            return AutoDiff(self.var, self.val + other.val, total)

        except AttributeError:

            return AutoDiff(self.var, self.val + other, self.der)

    def __radd__(self, other):
        """Performs addition on two AutoDiff objects"""
        return self.__add__(other)

    def __sub__(self, other):
        """Performs subtraction on two AutoDiff objects"""

        if type(other).__name__ is 'AutoDiffVector':
            return self.__add__(other.__neg__())

        try:
            total = Counter()
            total.update(self.der)
            total.update((-other).der)
                
            return AutoDiff(self.var, self.val - other.val, total)

        except AttributeError:

            return AutoDiff(self.var, self.val - other, self.der)

    def __rsub__(self, other):
        """Performs subtraction on two AutoDiff objects"""

        return self.__sub__(other)

    def __mul__(self, other):
        """Performs multiplication of an AutoDiff object with scalars and other AutoDiff objects"""
        
        if type(other).__name__ is 'AutoDiffVector':
            return other.__mul__(self)

        try:
            total = Counter()
            der1 = {k: other.val * v for k, v in self.der.items()}
            der2 = {k: self.val * v for k, v in other.der.items()}
            total.update(der1)
            total.update(der2)

            return AutoDiff(self.var, self.val * other.val, total)

        except AttributeError:

            der1 = {k: other * v for k, v in self.der.items()}
            der1 = Counter(der1)
            return AutoDiff(self.var, self.val * other, der1)


    def __rmul__(self, other):
        """Performs multiplication of an AutoDiff object with scalars and other AutoDiff objects"""

        return self.__mul__(other)

    def __neg__(self):
        """Returns the negation of an AutoDiff object"""
        neg = {k: -1 * v for k, v in self.der.items()}
        neg = Counter(neg)
        return AutoDiff(self.var, -self.val, neg)

    def reciprocal(self):
        """Returns the reciprocal of an AutoDiff object"""

        value = -1 / (self.val * self.val)
        der = {k: value * v for k, v in self.der.items()}
        return AutoDiff(self.var, 1 / self.val, der)

    def __truediv__(self,other):
        """Performs division of an AutoDiff object with scalars and other AutoDiff objects"""

        # if type(other).__name__ is 'AutoDiffVector':
        #     objects = []
        #     for i in range(len(other.objects)):
        #         new_object = self/(other.objects[list(other.objects.keys())[i]])
        #         objects.append(new_object)
        #     return AutoDiffVector(objects)
        if type(other).__name__ is 'AutoDiffVector':
            return other.__rtruediv__(self)
            #raise NotImplementedError("Division with AutoDiffVector object not implemented")

        try:
            return self * (other.reciprocal())
        except AttributeError:
            der = {k:v/other for k, v in self.der.items()}
            return AutoDiff(self.var,self.val/other,der)

    def __rtruediv__(self, other): 
        """Performs division of an AutoDiff object with scalars and other AutoDiff objects"""
        return other*self.reciprocal()

    def __pow__(self, power):
        """Performs exponentiation of an AutoDiff object with scalars values e.g x**3 """
        value = power * (self.val) ** (power - 1)
        der = {k: value * v for k, v in self.der.items()}
        return AutoDiff(self.var, self.val ** power, der)

    def __rpow__(self,power):
        """Performs exponentiation of an AutoDiff object with scalars values e.g. 3**x"""
        value =  power ** self.val
        der = {k: value * v * math.log(power) for k, v in self.der.items()}
        return AutoDiff(self.var, value, der)

    def __eq__(self, other):
        """Assesses the equality of two AutoDiff objects"""
        try:
            return self.val == other.val and self.der == other.der
        except:
            return False

    def __ne__(self, other):
        """Assesses the equality of two AutoDiff objects"""
        return not self.__eq__(other)

    def __lt__(self, other):
        """Assesses whether an AutoDiff object value is less than that of another AutoDiff object/given value"""
        try:
            return self.val < other.val
        except:
            return self.val < other

    def __le__(self, other):
        """Assesses whether an AutoDiff object value is less than or equal to that of another AutoDiff object/given value"""
        try:
            return self.val <= other.val
        except:
            return self.val <= other

    def __ge__(self, other):
        """Assesses whether an AutoDiff object value is greater than or equal to that of another AutoDiff object/given value"""
        try:
            return self.val >= other.val
        except:
            return self.val >= other

    def __gt__(self, other):
        """Assesses whether an AutoDiff object value is greater than that of another AutoDiff object/given value"""
        try:
            return self.val > other.val
        except:
            return self.val > other

class AutoDiffVector():
    def __init__(self, objects):
        
        self.objects = {}
        self.variables = []
        
        # Create dictionary of variables and the AutoDiff objects
        for i in range(len(objects)):
            if type(objects[i]).__name__ is not 'AutoDiff':
                raise ValueError('Variable inputs need to be AutoDiff objects!')

            self.objects[objects[i].var] = objects[i]
            self.variables.append(objects[i].var)
            
        if len(self.variables) != len(set(self.variables)):
            raise ValueError("Variable names cannot be the same")
        
        
    def __add__(self, other):
        """Performs addition of an AutoDiffVector object and either a scalar or an AutoDiff object"""

        objects = []
        for i in range(len(self.objects)):
            new_object = self.objects[list(self.objects.keys())[i]] + other
            objects.append(new_object)

        return AutoDiffVector(objects)
    
    def __radd__(self, other):
        """Performs right addition of an AutoDiffVector object and either a scalar or an AutoDiff object"""
        objects = []
        for i in range(len(self.objects)):
            new_object = self.objects[list(self.objects.keys())[i]] + other
            objects.append(new_object)

        return AutoDiffVector(objects)

    def __sub__(self, other):
        """Performs subtraction of an AutoDiffVector object and either a scalar or an AutoDiff object"""
        objects = []
        for i in range(len(self.objects)):
            new_object = self.objects[list(self.objects.keys())[i]] - other
            objects.append(new_object)
            
        return AutoDiffVector(objects)

    def __rsub__(self,other):
        """Performs right subtraction of an AutoDiffVector object and either a scalar or an AutoDiff object"""

        objects = []
        for i in range(len(self.objects)):
            new_object = other - self.objects[list(self.objects.keys())[i]]
            objects.append(new_object)
            
        return AutoDiffVector(objects)

    def __mul__(self, other):
        """Performs multiplication of an AutoDiffVector object and either a scalar or an AutoDiff object"""

        objects = []
        for i in range(len(self.objects)):
            new_object = self.objects[list(self.objects.keys())[i]] * other
            objects.append(new_object)
            
        return AutoDiffVector(objects)

    def __rmul__(self, other):
        """Performs right multiplication of an AutoDiffVector object and either a scalar or an AutoDiff object"""
        return self.__mul__(other)

    def __neg__(self):
        """Performs negation of an AutoDiffVector object and either a scalar or an AutoDiff object"""

        objects = []
        for i in range(len(self.objects)):
            new_object = -self.objects[list(self.objects.keys())[i]]
            objects.append(new_object)
            
        return AutoDiffVector(objects)


    def __truediv__(self, other):
        """Performs division of an AutoDiffVector object and either a scalar or an AutoDiff object"""

        objects = []
        for i in range(len(self.objects)):
            new_object = (self.objects[list(self.objects.keys())[i]])/other
            objects.append(new_object)
            
        return AutoDiffVector(objects)

    def __rtruediv__(self, other):
        """Performs right division of an AutoDiffVector object and either a scalar or an AutoDiff object"""
        #raise NotImplementedError("Division of AutoDiff object with AutoDiffVector object not implemented")
        
        objects = []
        for i in range(len(self.objects)):
            new_object = (self.objects[list(self.objects.keys())[i]]).reciprocal() * other
            objects.append(new_object)
        return AutoDiffVector(objects)
        #return other * self.reciprocal()

    def __pow__(self, other):
        """Performs exponentiation of an AutoDiffVector object and either a scalar or an AutoDiff object"""

        objects = []
        for i in range(len(self.objects)):
            new_object = (self.objects[list(self.objects.keys())[i]]) ** other
            objects.append(new_object)
            
        return AutoDiffVector(objects)

    def __rpow__(self, other):
        """Performs right exponentiation of an AutoDiffVector object and either a scalar or an AutoDiff object"""

        objects = []
        for i in range(len(self.objects)):
            new_object = other ** (self.objects[list(self.objects.keys())[i]])
            objects.append(new_object)

        return AutoDiffVector(objects)



def vectorize(var, val, der=1.0):
    """Function takes in an array of variable names, values, and derivatives and creates an AutoDiffVector object"""

    # Ensure that input vectors are list types
    if type(var) != list or type(val) != list:
        raise TypeError("Input array of variables and values need to be of list type")

    # If der is specified, check that it is a list type
    if der != 1.0 and type(der) != list:
        raise TypeError("If derivatives are specified, derivative array needs to be a list")

    # Ensure that var and val are of the same length
    if len(var) != len(val):
        raise KeyError("Input array of variables and values need to be of the same length")

    # If der is specified, check that it is also of the same length
    if der != 1.0 and len(der) != len(val):
        raise KeyError("If derivatives are specified, derivative array needs to be of the same length as the array of variables")

    # If der is unspecified, create a vector of 1.0 values with length equal to input array
    if der == 1.0:
        der = [1.0] * len(var)
        
    # Ensure that the variable names are not repeated
    if len(var) != len(set(var)):
        raise ValueError("Variable names cannot be the same")

    # If everything checks out, create AutoDiff objects and to convert into an AutoDiffVector object
    objects = []

    for i in range(len(var)):
        objects.append(AutoDiff(var[i], val[i], der[i]))
    
    return AutoDiffVector(objects)

# Helper function required for variable naming
def round_3sf(x, sig=3):
    """Rounds a numeric input to 3 significant figures"""
    return round(x, sig-int(math.floor(math.log10(abs(x))))-1)
