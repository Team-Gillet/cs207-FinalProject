# CS207-FinalProject
## superautodiff

Group number 1
Members: Lucie Gillet, Jovin Leong, Jussi Sakari Jukarainen, Huahua Zheng

[![Build Status](https://travis-ci.org/Team-Gillet/cs207-FinalProject.svg?branch=master)](https://travis-ci.org/Team-Gillet/cs207-FinalProject.svg?branch=master)

[![Coverage Status](https://codecov.io/gh/Team-Gillet/cs207-FinalProject/branch/master/graph/badge.svg)](https://codecov.io/gh/Team-Gillet/cs207-FinalProject)


